public interface Measurable {

	public double getMeasure();

}
