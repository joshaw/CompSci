/**  This class is to test the ComputerAccout class and its methods.
 *   We create an object of class ComputerAccout, print this to the screen and
 *   change the password associated with the account.
 */
public class StudentTest {

	public static void main(String[] args){

		/* Creates a new Student with name John Smith, studentID 1111111 and
		 * course ICY */
		Student testStudent = new Student("John Smith", "1111111", "ICY");

		// Print the Student using the toString method.
		System.out.println(testStudent);

	}

}
